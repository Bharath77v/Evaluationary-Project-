# Reflection Brief — Evaluation and Observability Capstone

## Environment

- OS: Debian GNU/Linux 12 (bookworm)
- Python: 3.13.0
- Three systems were installed from their final `solution/` directories.
- No API keys or secrets are included in this evidence package.

## 1. Policy Pipeline

The Policy Pipeline automated tests collected 48 tests, with 45 passing and 3 skipped. Ruff reported that all checks passed, while mypy reported five errors in test files. A live pipeline execution was attempted, but the Anthropic API returned HTTP 401 Unauthorized because the configured credential was invalid. Therefore, no live routing decisions are claimed in this submission. The deterministic tests still provide evidence for the intended routing behavior, including human-review conditions.

## 2. Mortgage Extraction

The Mortgage Extraction system passed all 25 automated tests. Ruff reported all checks passed; mypy reported six errors in two test files. A normal extraction run successfully extracted borrower and income information and reported the validation as consistent. A deliberate discrepancy run changed the relationship between stated and calculated income totals and the validator correctly reported `consistent: false`, with a calculated value of 9642.17 versus a stated value of 10892.17 and a delta of -1250.0.

## 3. Supply Chain Investigation

The Supply Chain Investigation system passed all 34 automated tests. Ruff reported all checks passed; mypy encountered one dependency parsing error involving the installed NumPy type stubs. The normal offline Meridian investigation produced a traceable briefing containing corroborated, contested, and incomplete information. The on-time delivery rate was contested between 95 percent and 78 percent and was escalated. The production capacity metric had no usable source and was escalated.

The timeout perturbation simulated an unavailable logistics source. The resulting briefing explicitly reported that logistics was unavailable because of a timeout, marked the affected late-shipment metric as incomplete, and still completed the investigation. This demonstrated graceful degradation rather than terminating the complete workflow.

## Evaluation Findings

The strongest evidence came from the automated test suites and deterministic/offline runs. The Mortgage system demonstrated mathematical discrepancy detection, while the Supply Chain system demonstrated source corroboration, conflict handling, escalation, missing-source handling, and timeout resilience. The Policy system demonstrated strong automated test coverage, but live API authentication prevented a live pipeline evaluation.

## Limitations

The Policy live pipeline could not be evaluated because the Anthropic API credential available in the workspace was rejected with HTTP 401 Unauthorized. Consequently, no live Policy routing JSON was fabricated. Static type checking also reported test/dependency issues in all three projects, although Ruff passed for each system.

## Lessons Learned

Evaluation evidence should distinguish actual observations from assumptions. Passing functional tests is useful, but robustness experiments reveal behavior that ordinary tests may not expose. Source availability, conflicting evidence, authentication failures, and dependency compatibility can all affect the reproducibility of an AI workflow. Preserving the actual outputs of tests and experiments makes the final evaluation auditable.
