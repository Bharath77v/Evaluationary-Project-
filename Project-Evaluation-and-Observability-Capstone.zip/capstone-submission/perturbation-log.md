# Perturbation Log

## 1. Policy Pipeline — Authentication Perturbation

**Change:** Attempted the live Policy pipeline with the available Anthropic credential.

**Expected:** The pipeline should authenticate and process the policy documents.

**Actual:** The Anthropic API returned HTTP 401 Unauthorized because the API key was invalid.

**Result:** No live routing decisions were generated. The submission does not claim fabricated live routing results.

## 2. Mortgage Extraction — Mathematical Discrepancy

**Change:** Used `fixtures/documents/income_sum_mismatch.txt`, where the stated monthly income total does not equal the sum of the extracted components.

**Expected:** The consistency validator should detect the discrepancy.

**Actual:** The calculated total was 9642.17 while the stated total was 10892.17, producing a delta of -1250.0. The validator returned `consistent: false`.

**Result:** The perturbation successfully exposed the mathematical inconsistency.

## 3. Supply Chain — Source Timeout

**Change:** Ran `supply-chain-investigate meridian --offline --simulate-timeout`.

**Expected:** The unavailable source should be identified and affected evidence should become incomplete without terminating the investigation.

**Actual:** The logistics source was reported as unavailable because of a timeout. `late_shipment_count` became incomplete, while the investigation continued and produced a complete briefing.

**Result:** The workflow demonstrated graceful degradation under a source timeout.
